//
//  DetailsViewController.swift
//  PostsProject
//
//  Created by Олег Курбатов on 01.09.2023.
//

import UIKit
import Alamofire

struct PostDetails: Codable {
    let postId: Int?
    let timeshamp: Int?
    let title: String?
    let text: String?
    let postImage: String?
    let likesCount: Int?

    enum CodingKeys: String, CodingKey {
        case postId = "postId"
        case timeshamp = "timeshamp"
        case title = "title"
        case text = "text"
        case postImage = "postImage"
        case likesCount = "likes_count"
    }
    
}

class DetailsViewController: UIViewController {
    
    @IBOutlet weak var centralImageView: UIImageView!
    @IBOutlet weak var titleText: UILabel!
    @IBOutlet weak var detailsText: UILabel!
    @IBOutlet weak var countOfLikes: UILabel!
    @IBOutlet weak var imageHeart: UIImageView!
    @IBOutlet weak var timePost: UILabel!
    
    var newPostsArray: Posts?

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
